<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Node extends MY_model {
    
    protected $categories, $categories_array, $array;
    
	function __construct()	{	   
		parent::__construct();     
	} 
    
 }