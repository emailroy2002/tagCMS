<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Search extends MY_model {
    
	function __construct()	{	   
		parent::__construct();
	}
    
    

 }    