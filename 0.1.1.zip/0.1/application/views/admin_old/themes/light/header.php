<div id="header">
    <div style="height:90px; background-color:#ccc"></div>
</div>
