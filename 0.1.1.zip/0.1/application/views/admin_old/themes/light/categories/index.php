    <h1>Categories</h1>
    
	<div id="body">
    <pre>
        <?php echo $categories ?>
	</div>

  

    